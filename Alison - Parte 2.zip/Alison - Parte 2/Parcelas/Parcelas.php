<!DOCTYPE html>
<html>
<head>
    <title>Calculadora de Parcelas</title>
</head>
<body>
    <h1>Calculadora de Parcelas</h1>
    
    <?php
        $produto = 0;
        $porcentagem = 0;
        $parcela = 0;
        $valorTotal = 0;

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $produto = $_POST["produto"];
            $porcentagem = $produto * 0.16;
            $valorTotal = $produto + $porcentagem;
            $parcela = $valorTotal / 10;
        }
    ?>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="produto">Informe o valor do produto:</label>
        <input type="text" name="produto" id="produto" required>
        <input type="submit" value="Calcular">
    </form>

    <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
        <p>O valor de uma parcela desse produto é igual a: <?php echo $parcela; ?></p>
        <p>Sendo assim, o valor total das parcelas fica: <?php echo $valorTotal; ?></p>
    <?php endif; ?>
</body>
</html>