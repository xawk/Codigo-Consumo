<!DOCTYPE html>
<html>
<head>
    <title>Verificação de Triângulo</title>
</head>
<body>
    <h1>Verificação de Triângulo</h1>
    <form method="post" action="">
        <label>Informe em (metros) os 3 lados do triângulo:</label>
        <input type="text" name="num1" placeholder="Lado 1">
        <input type="text" name="num2" placeholder="Lado 2">
        <input type="text" name="num3" placeholder="Lado 3">
        <input type="submit" name="submit" value="Verificar">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        $num3 = $_POST['num3'];

        if ($num1 == $num2 && $num2 == $num3) {
            echo "Esse triângulo é Equilátero!";
        } elseif ($num1 != $num2 && $num2 != $num3 && $num1 != $num3) {
            echo "Esse triângulo é Escaleno!";
        } else {
            echo "Esse triângulo é Isósceles!";
        }
    }
    ?>
</body>
</html>