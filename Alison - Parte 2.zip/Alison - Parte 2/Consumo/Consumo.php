<!DOCTYPE html>
<html>
<head>
    <title>Calculadora de Consumo de Combustível</title>
</head>
<body>
    <h1>Calculadora de Consumo de Combustível</h1>
    
    <?php
        $distancia = 0;
        $combustivel = 0;
        $consumoMedio = 0;

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $distancia = $_POST["distancia"];
            $combustivel = $_POST["combustivel"];
            $consumoMedio = $distancia / $combustivel;
        }
    ?>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="distancia">Informe a distância em (km) que o carro percorreu:</label>
        <input type="text" name="distancia" id="distancia" required><br>

        <label for="combustivel">Informe a quantidade em (L) de combustível usado no trajeto:</label>
        <input type="text" name="combustivel" id="combustivel" required><br>

        <input type="submit" value="Calcular">
    </form>

    <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
        <p>O consumo médio de combustível foi de: <?php echo $consumoMedio; ?> km/L</p>
    <?php endif; ?>
</body>
</html>